﻿namespace DreamLists.Models
{
    public class DreamList
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }

        public string AccomplishBy { get; set; }
    }
}
